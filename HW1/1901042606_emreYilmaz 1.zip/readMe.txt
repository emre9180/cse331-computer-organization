# How you should enter the numbers is written in ASM file, too.
# Input style is the same as the sample input in the PDF.


Input style:

3 5              >> How I get n and k.
1 2 3 4 5        >> How I get array elements.


